package com.vehicle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class AddVehicle {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String url = "jdbc:mysql://localhost:3306/vehicle_rental";
        String username = "root";
        String password = "Prachi@13";

        try {
            System.out.print("Enter vehicle name: ");
            String name = sc.nextLine();

            System.out.print("Enter vehicle type: ");
            String type = sc.nextLine();

            System.out.print("Enter registration number: ");
            String registrationNo = sc.nextLine();

            System.out.print("Enter price per day: ");
            double price = sc.nextDouble();

            Connection con =
                    DriverManager.getConnection(url, username, password);

            String query =
                    "INSERT INTO vehicles " +
                    "(vehicle_name, vehicle_type, registration_no, rent_per_day, status) " +
                    "VALUES (?, ?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, name);
            ps.setString(2, type);
            ps.setString(3, registrationNo);
            ps.setDouble(4, price);
            ps.setString(5, "Available");

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("\nVehicle added successfully!");
            }

            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}