package com.vehicle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class VehicleList {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/vehicle_rental";
        String username = "root";
        String password = "Prachi@13";

        try {
            Connection con = DriverManager.getConnection(url, username, password);

            String query = "SELECT * FROM vehicles";

            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                System.out.println(
                    rs.getInt("vehicle_id") + " | " +
                    rs.getString("vehicle_name") + " | " +
                    rs.getString("vehicle_type") + " | " +
                    rs.getString("registration_no") + " | " +
                    rs.getDouble("rent_per_day") + " | " +
                    rs.getString("status")
                );
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}