package com.vehicle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class UpdateVehicle {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String url = "jdbc:mysql://localhost:3306/vehicle_rental";
        String username = "root";
        String password = "Prachi@13";

        try {

            System.out.print("Enter vehicle ID: ");
            int vehicleId = sc.nextInt();

            System.out.print("Enter new rent per day: ");
            double rent = sc.nextDouble();

            Connection con =
                    DriverManager.getConnection(url, username, password);

            String query =
                    "UPDATE vehicles SET rent_per_day = ? WHERE vehicle_id = ?";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setDouble(1, rent);
            ps.setInt(2, vehicleId);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("\nVehicle updated successfully!");
            } else {
                System.out.println("\nVehicle not found!");
            }

            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}