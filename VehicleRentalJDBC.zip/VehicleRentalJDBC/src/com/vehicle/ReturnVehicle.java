package com.vehicle;

import java.sql.*;
import java.util.Scanner;

public class ReturnVehicle {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String url = "jdbc:mysql://localhost:3306/vehicle_rental";
        String username = "root";
        String password = "Prachi@13";

        try {

            System.out.print("Enter Rental ID: ");
            int rentalId = sc.nextInt();

            Connection con =
                    DriverManager.getConnection(url, username, password);

            // Find vehicle for this rental
            String findQuery =
                    "SELECT vehicle_id, status FROM rentals WHERE rental_id = ?";

            PreparedStatement findPs =
                    con.prepareStatement(findQuery);

            findPs.setInt(1, rentalId);

            ResultSet rs = findPs.executeQuery();

            if (!rs.next()) {
                System.out.println("Rental not found!");
                return;
            }

            int vehicleId = rs.getInt("vehicle_id");
            String rentalStatus = rs.getString("status");

            if (rentalStatus.equalsIgnoreCase("Completed")) {
                System.out.println("This rental is already completed!");
                return;
            }

            // Update rental
            String rentalUpdate =
                    "UPDATE rentals SET status = 'Completed' WHERE rental_id = ?";

            PreparedStatement rentalPs =
                    con.prepareStatement(rentalUpdate);

            rentalPs.setInt(1, rentalId);
            rentalPs.executeUpdate();

            // Update vehicle
            String vehicleUpdate =
                    "UPDATE vehicles SET status = 'Available' WHERE vehicle_id = ?";

            PreparedStatement vehiclePs =
                    con.prepareStatement(vehicleUpdate);

            vehiclePs.setInt(1, vehicleId);
            vehiclePs.executeUpdate();

            System.out.println("\nVehicle returned successfully!");
            System.out.println("Vehicle status changed to Available.");

            rs.close();
            findPs.close();
            rentalPs.close();
            vehiclePs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}