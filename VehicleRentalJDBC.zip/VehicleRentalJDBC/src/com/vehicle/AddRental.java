package com.vehicle;

import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class AddRental {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String url = "jdbc:mysql://localhost:3306/vehicle_rental";
        String username = "root";
        String password = "Prachi@13";

        try {
            System.out.print("Enter Customer ID: ");
            int customerId = sc.nextInt();

            System.out.print("Enter Vehicle ID: ");
            int vehicleId = sc.nextInt();

            sc.nextLine();

            System.out.print("Enter Rental Date (YYYY-MM-DD): ");
            LocalDate rentalDate = LocalDate.parse(sc.nextLine());

            System.out.print("Enter Return Date (YYYY-MM-DD): ");
            LocalDate returnDate = LocalDate.parse(sc.nextLine());

            if (!returnDate.isAfter(rentalDate)) {
                System.out.println("Return date must be after rental date!");
                return;
            }

            Connection con =
                    DriverManager.getConnection(url, username, password);

            // Check customer
            String customerQuery =
                    "SELECT customer_id FROM customers WHERE customer_id = ?";

            PreparedStatement customerPs =
                    con.prepareStatement(customerQuery);

            customerPs.setInt(1, customerId);

            ResultSet customerRs = customerPs.executeQuery();

            if (!customerRs.next()) {
                System.out.println("Customer not found!");
                return;
            }

            // Check vehicle
            String vehicleQuery =
                    "SELECT rent_per_day, status FROM vehicles WHERE vehicle_id = ?";

            PreparedStatement vehiclePs =
                    con.prepareStatement(vehicleQuery);

            vehiclePs.setInt(1, vehicleId);

            ResultSet vehicleRs = vehiclePs.executeQuery();

            if (!vehicleRs.next()) {
                System.out.println("Vehicle not found!");
                return;
            }

            double rentPerDay = vehicleRs.getDouble("rent_per_day");
            String status = vehicleRs.getString("status");

            if (!status.equalsIgnoreCase("Available")) {
                System.out.println("Vehicle is not available!");
                return;
            }

            long days = ChronoUnit.DAYS.between(rentalDate, returnDate);
            double totalAmount = days * rentPerDay;

            System.out.println("\n===== RENTAL SUMMARY =====");
            System.out.println("Rental Days: " + days);
            System.out.println("Rent Per Day: " + rentPerDay);
            System.out.println("Total Amount: " + totalAmount);

            String rentalQuery =
                    "INSERT INTO rentals " +
                    "(customer_id, vehicle_id, rental_date, return_date, total_amount, status) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";

            PreparedStatement rentalPs =
                    con.prepareStatement(rentalQuery);

            rentalPs.setInt(1, customerId);
            rentalPs.setInt(2, vehicleId);
            rentalPs.setDate(3, Date.valueOf(rentalDate));
            rentalPs.setDate(4, Date.valueOf(returnDate));
            rentalPs.setDouble(5, totalAmount);
            rentalPs.setString(6, "Active");

            int rows = rentalPs.executeUpdate();

            if (rows > 0) {

                String updateVehicle =
                        "UPDATE vehicles SET status = 'Rented' WHERE vehicle_id = ?";

                PreparedStatement updatePs =
                        con.prepareStatement(updateVehicle);

                updatePs.setInt(1, vehicleId);
                updatePs.executeUpdate();

                updatePs.close();

                System.out.println("\nRental created successfully!");
                System.out.println("Vehicle status changed to Rented.");
            }

            customerRs.close();
            customerPs.close();
            vehicleRs.close();
            vehiclePs.close();
            rentalPs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}