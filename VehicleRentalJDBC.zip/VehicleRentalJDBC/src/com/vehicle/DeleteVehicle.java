package com.vehicle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class DeleteVehicle {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String url = "jdbc:mysql://localhost:3306/vehicle_rental";
        String username = "root";
        String password = "Prachi@13";

        try {

            System.out.print("Enter vehicle ID to delete: ");
            int vehicleId = sc.nextInt();

            Connection con =
                    DriverManager.getConnection(url, username, password);

            String query =
                    "DELETE FROM vehicles WHERE vehicle_id = ?";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, vehicleId);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("\nVehicle deleted successfully!");
            } else {
                System.out.println("\nVehicle not found!");
            }

            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}