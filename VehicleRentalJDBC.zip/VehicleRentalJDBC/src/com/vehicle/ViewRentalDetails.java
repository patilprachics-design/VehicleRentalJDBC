package com.vehicle;

import java.sql.*;

public class ViewRentalDetails {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/vehicle_rental";
        String username = "root";
        String password = "YOUR_PASSWORD";

        try {

            Connection con =
                    DriverManager.getConnection(url, username, password);

            String query =
                    "SELECT r.rental_id, " +
                    "c.customer_name, " +
                    "v.vehicle_name, " +
                    "v.registration_no, " +
                    "r.rental_date, " +
                    "r.return_date, " +
                    "r.total_amount, " +
                    "r.status " +
                    "FROM rentals r " +
                    "JOIN customers c ON r.customer_id = c.customer_id " +
                    "JOIN vehicles v ON r.vehicle_id = v.vehicle_id";

            PreparedStatement ps =
                    con.prepareStatement(query);

            ResultSet rs = ps.executeQuery();

            System.out.println("\n========== RENTAL DETAILS ==========");

            while (rs.next()) {

                System.out.println("------------------------------------");
                System.out.println("Rental ID       : " + rs.getInt("rental_id"));
                System.out.println("Customer Name   : " + rs.getString("customer_name"));
                System.out.println("Vehicle         : " + rs.getString("vehicle_name"));
                System.out.println("Registration No : " + rs.getString("registration_no"));
                System.out.println("Rental Date     : " + rs.getDate("rental_date"));
                System.out.println("Return Date     : " + rs.getDate("return_date"));
                System.out.println("Total Amount    : " + rs.getDouble("total_amount"));
                System.out.println("Status          : " + rs.getString("status"));
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}