package com.vehicle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class UpdateVehicleStatus {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/vehicle_rental";
        String username = "root";
        String password = "Prachi@13";

        try {
            Connection con =
                    DriverManager.getConnection(url, username, password);

            String query =
                    "UPDATE vehicles SET status = ? WHERE vehicle_id = ?";

            PreparedStatement ps = con.prepareStatement(query);

            // Set vehicle status to Rented
            ps.setString(1, "Rented");

            // Honda City vehicle_id = 1
            ps.setInt(2, 1);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Vehicle status updated successfully!");
            }

            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}