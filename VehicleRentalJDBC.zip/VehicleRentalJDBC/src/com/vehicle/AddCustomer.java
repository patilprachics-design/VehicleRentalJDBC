package com.vehicle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class AddCustomer {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String url = "jdbc:mysql://localhost:3306/vehicle_rental";
        String username = "root";
        String password = "Prachi@13";

        try {

            System.out.print("Enter customer name: ");
            String name = sc.nextLine();

            System.out.print("Enter phone number: ");
            String phone = sc.nextLine();

            System.out.print("Enter email: ");
            String email = sc.nextLine();

            System.out.print("Enter address: ");
            String address = sc.nextLine();

            Connection con =
                    DriverManager.getConnection(url, username, password);

            String query =
                    "INSERT INTO customers " +
                    "(customer_name, phone, email, address) " +
                    "VALUES (?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, name);
            ps.setString(2, phone);
            ps.setString(3, email);
            ps.setString(4, address);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("\nCustomer added successfully!");
            }

            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}