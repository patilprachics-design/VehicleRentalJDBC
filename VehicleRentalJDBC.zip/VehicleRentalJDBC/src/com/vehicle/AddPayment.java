package com.vehicle;

import java.sql.*;
import java.time.LocalDate;
import java.util.Scanner;

public class AddPayment {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String url = "jdbc:mysql://localhost:3306/vehicle_rental";
        String username = "root";
        String password = "Prachi@13";

        try {

            System.out.print("Enter Rental ID: ");
            int rentalId = sc.nextInt();

            System.out.print("Enter Payment Amount: ");
            double amount = sc.nextDouble();

            sc.nextLine();

            System.out.print("Enter Payment Method (UPI/Card/Cash): ");
            String method = sc.nextLine();

            Connection con =
                    DriverManager.getConnection(url, username, password);

            // Check rental
            String checkQuery =
                    "SELECT rental_id FROM rentals WHERE rental_id = ?";

            PreparedStatement checkPs =
                    con.prepareStatement(checkQuery);

            checkPs.setInt(1, rentalId);

            ResultSet rs = checkPs.executeQuery();

            if (!rs.next()) {
                System.out.println("Rental not found!");
                return;
            }

            String query =
                    "INSERT INTO payments " +
                    "(rental_id, payment_date, amount, payment_method, payment_status) " +
                    "VALUES (?, ?, ?, ?, ?)";

            PreparedStatement ps =
                    con.prepareStatement(query);

            ps.setInt(1, rentalId);
            ps.setDate(2, Date.valueOf(LocalDate.now()));
            ps.setDouble(3, amount);
            ps.setString(4, method);
            ps.setString(5, "Paid");

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("\nPayment added successfully!");
            }

            rs.close();
            checkPs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}