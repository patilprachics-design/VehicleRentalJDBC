package com.vehicle;

import java.util.Scanner;

public class MainMenu {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        while (true) {

            System.out.println("\n===== VEHICLE RENTAL MANAGEMENT SYSTEM =====");
            System.out.println("1. View Vehicles");
            System.out.println("2. Add Vehicle");
            System.out.println("3. Update Vehicle");
            System.out.println("4. Delete Vehicle");
            System.out.println("5. Add Customer");
            System.out.println("6. Create Rental");
            System.out.println("7. Return Vehicle");
            System.out.println("8. Add Payment");
            System.out.println("9. View Rental Details");
            System.out.println("10. Exit");

            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    VehicleList.main(null);

                    System.out.println("\nPress Enter to continue...");
                    sc.nextLine();
                    sc.nextLine();
                    break;

                case 2:
                    AddVehicle.main(null);

                    System.out.println("\nPress Enter to continue...");
                    sc.nextLine();
                    sc.nextLine();
                    break;

                case 3:
                    UpdateVehicle.main(null);

                    System.out.println("\nPress Enter to continue...");
                    sc.nextLine();
                    sc.nextLine();
                    break;

                case 4:
                    DeleteVehicle.main(null);

                    System.out.println("\nPress Enter to continue...");
                    sc.nextLine();
                    sc.nextLine();
                    break;

                case 5:
                    AddCustomer.main(null);

                    System.out.println("\nPress Enter to continue...");
                    sc.nextLine();
                    sc.nextLine();
                    break;

                case 6:
                    AddRental.main(null);

                    System.out.println("\nPress Enter to continue...");
                    sc.nextLine();
                    sc.nextLine();
                    break;

                case 7:
                    ReturnVehicle.main(null);

                    System.out.println("\nPress Enter to continue...");
                    sc.nextLine();
                    sc.nextLine();
                    break;

                case 8:
                    AddPayment.main(null);

                    System.out.println("\nPress Enter to continue...");
                    sc.nextLine();
                    sc.nextLine();
                    break;

                case 9:
                    ViewRentalDetails.main(null);

                    System.out.println("\nPress Enter to continue...");
                    sc.nextLine();
                    sc.nextLine();
                    break;

                case 10:
                    System.out.println("\nThank you for using Vehicle Rental Management System!");
                    sc.close();
                    return;

                default:
                    System.out.println("\nInvalid choice! Please try again.");
            }
        }
    }
}